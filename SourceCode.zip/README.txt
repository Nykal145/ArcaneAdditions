﻿
Arcane Additions: Wrath of the Righteous

FEATURES 
• School Savant Arcanist archeytpe
• Optional mythic ablity school increases w/ customizable amounts
• Optional Tabletop Spell Ranges 
• Optional Level Based Spell Ranges

FEATURES: suggested settings for balance 
• Level Based Range increase but with the WotR default ranges
• 1 point Mythic ASI



CREDITS
♦ Pathfinder Wrath of The Righteous Discord channel members
♦ Spacehamster - awesome tutorials.
♦ Barley for this credits format.
♦ Call of the Wild for examples and helpers to start with.
♦ @Vek17, @Bubbles, @Balkoth, @Narria, @Spacehamster, @Barley and the rest of our great Discord modding community - help.
♦ PS: Spacehamster 's Modding Wiki is an excellent place to start if you want to start moding on your own. (https://github.com/spacehamster/OwlcatModdingWiki/wiki/Beginner-Guide)